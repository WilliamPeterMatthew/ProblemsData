#include<bits/stdc++.h>
using namespace std;
char b[50][50]={"air","stone","grass","dirt","cobblestone","planks","sapling","bedrock","flowing_water","water","flowing_lava","lava","sand","gravel","gold_ore","iron_ore","coal_ore","log","leaves","sponge","glass","lapis_ore","lapis_block","dispenser","sandstone","noteblock","bed","golden_rail","detector_rail","sticky_piston","web","tallgrass","deadbush","piston","piston_head","wool","piston_extension","yellow_flower","red_flower","brown_mushroom","red_mushroom","gold_block","iron_block","double_stone_slab","stone_slab","brick_block","tnt","bookshelf","mossy_cobblestone","obsidian"};
int a;
int main()
{
	freopen("ta.in","r",stdin);
	freopen("ta.out","w",stdout);
	scanf("%d",&a);
	printf("minecraft:%s\n",b[a]);
	return 0;
}
