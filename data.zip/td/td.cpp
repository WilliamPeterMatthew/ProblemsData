#include<bits/stdc++.h>
using namespace std;
int n;
long long a[55];
int main()
{
	freopen("td.in","r",stdin);
	freopen("td.out","w",stdout);
	scanf("%d",&n);
	if(n==0)
	{
		printf("1");
		return 0;
	}
	a[0]=1;
	for(int m=1;m<=n;m++)
	{
		a[m]=a[m-1]*(n-m+1)/m;
	}
	for(int i=1;i<=n;i++)
	{
		a[i+1]+=a[i]/10;
		a[i]%=10;
	}
	for(int i=0;i<=n;i++)
	{
		if(a[i])
		{
			if(i>0)printf("+");
			if(a[i]>1)cout<<a[i];
			if(i<n)
			{
				printf("a");
				if(i<n-1)printf("^%d",n-i);
			}
			if(i>0)
			{
				printf("b");
				if(i>1)printf("^%d",i);
			}
		}
	}
	if(a[n+1])cout<<"+"<<a[n+1];
	return 0;
}
