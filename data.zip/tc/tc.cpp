#include<bits/stdc++.h>
using namespace std;
char a[15];
int main()
{
	freopen("tc.in","r",stdin);
	freopen("tc.out","w",stdout);
	scanf("%s",a);
	if(a[0]=='M'&&a[1]=='_')
	{
		if(a[2]=='E')
		{
			printf("%.6lf",M_E);
			return 0;
		}
		if(a[2]=='L'&&a[3]=='O'&&a[5]=='2')
		{
			printf("%.6lf",M_LOG2E);
			return 0;
		}
		if(a[2]=='L'&&a[3]=='O'&&a[5]=='1')
		{
			printf("%.6lf",M_LOG10E);
			return 0;
		}
		if(a[2]=='L'&&a[3]=='N'&&a[4]=='2')
		{
			printf("%.6lf",M_LN2);
			return 0;
		}
		if(a[2]=='L'&&a[3]=='N'&&a[4]=='1')
		{
			printf("%.6lf",M_LN10);
			return 0;
		}
		if(a[2]=='P'&&a[4]!='_')
		{
			printf("%.6lf",M_PI);
			return 0;
		}
		if(a[2]=='P'&&a[5]=='2')
		{
			printf("%.6lf",M_PI_2);
			return 0;
		}
		if(a[2]=='P'&&a[5]=='4')
		{
			printf("%.6lf",M_PI_4);
			return 0;
		}
		if(a[2]=='1'&&a[4]=='P')
		{
			printf("%.6lf",M_1_PI);
			return 0;
		}
		if(a[2]=='2'&&a[4]=='P')
		{
			printf("%.6lf",M_2_PI);
			return 0;
		}
		if(a[2]=='2'&&a[4]=='S')
		{
			printf("%.6lf",M_2_SQRTPI);
			return 0;
		}
		if(a[2]=='S'&&a[6]=='2')
		{
			printf("%.6lf",M_SQRT2);
			return 0;
		}
		if(a[2]=='S'&&a[6]=='1')
		{
			printf("%.6lf",M_SQRT1_2);
			return 0;
		}
	}
	{
		if(a[0]=='N'&&a[1]=='U'&&a[2]=='L')
		{
			printf("0");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='O'&&a[2]=='H')
		{
			printf("1");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='T'&&a[2]=='X')
		{
			printf("2");
			return 0;
		}
		if(a[0]=='E'&&a[1]=='T'&&a[2]=='X')
		{
			printf("3");
			return 0;
		}
		if(a[0]=='E'&&a[1]=='O'&&a[2]=='T')
		{
			printf("4");
			return 0;
		}
		if(a[0]=='E'&&a[1]=='N'&&a[2]=='Q')
		{
			printf("5");
			return 0;
		}
		if(a[0]=='A'&&a[1]=='C'&&a[2]=='K')
		{
			printf("6");
			return 0;
		}
		if(a[0]=='B'&&a[1]=='E'&&a[2]=='L')
		{
			printf("7");
			return 0;
		}
		if(a[0]=='B'&&a[1]=='S')
		{
			printf("8");
			return 0;
		}
		if(a[0]=='T'&&a[1]=='A'&&a[2]=='B')
		{
			printf("9");
			return 0;
		}
		if(a[0]=='L'&&a[1]=='F')
		{
			printf("10");
			return 0;
		}
		if(a[0]=='V'&&a[1]=='T')
		{
			printf("11");
			return 0;
		}
		if(a[0]=='F'&&a[1]=='F')
		{
			printf("12");
			return 0;
		}
		if(a[0]=='C'&&a[1]=='R')
		{
			printf("13");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='O')
		{
			printf("14");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='I')
		{
			printf("15");
			return 0;
		}
		if(a[0]=='D'&&a[1]=='L'&&a[2]=='E')
		{
			printf("16");
			return 0;
		}
		if(a[0]=='D'&&a[1]=='C'&&a[2]=='1')
		{
			printf("17");
			return 0;
		}
		if(a[0]=='D'&&a[1]=='C'&&a[2]=='2')
		{
			printf("18");
			return 0;
		}
		if(a[0]=='D'&&a[1]=='C'&&a[2]=='3')
		{
			printf("19");
			return 0;
		}
		if(a[0]=='D'&&a[1]=='C'&&a[2]=='4')
		{
			printf("20");
			return 0;
		}
		if(a[0]=='N'&&a[1]=='A'&&a[2]=='K')
		{
			printf("21");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='Y'&&a[2]=='N')
		{
			printf("22");
			return 0;
		}
		if(a[0]=='E'&&a[1]=='T'&&a[2]=='B')
		{
			printf("23");
			return 0;
		}
		if(a[0]=='C'&&a[1]=='A'&&a[2]=='N')
		{
			printf("24");
			return 0;
		}
		if(a[0]=='E'&&a[1]=='M')
		{
			printf("25");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='U'&&a[2]=='B')
		{
			printf("26");
			return 0;
		}
		if(a[0]=='E'&&a[1]=='S'&&a[2]=='C')
		{
			printf("27");
			return 0;
		}
		if(a[0]=='F'&&a[1]=='S')
		{
			printf("28");
			return 0;
		}
		if(a[0]=='G'&&a[1]=='S')
		{
			printf("29");
			return 0;
		}
		if(a[0]=='R'&&a[1]=='S')
		{
			printf("30");
			return 0;
		}
		if(a[0]=='U'&&a[1]=='S')
		{
			printf("31");
			return 0;
		}
		if(a[0]=='S'&&a[1]=='p'&&a[2]=='a'&&a[3]=='c'&&a[4]=='e')
		{
			printf("32");
			return 0;
		}
		if(a[0]=='D'&&a[1]=='E'&&a[2]=='L')
		{
			printf("127");
			return 0;
		}
		{
			int tot=0;
			for(int i=0;i<strlen(a);i++)
			{
				tot+=int(a[i]);
			}
			printf("%d",tot);
		}
	}
	return 0;
}
