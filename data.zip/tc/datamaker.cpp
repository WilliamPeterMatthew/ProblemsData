#include<bits/stdc++.h>
using namespace std;
char a[15];
const char* problemname="tc";
char buf[200]={};
int t=0;
int main()
{
//	scanf("%s",a);
	{
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			cerr<<"data "<<t<<" has been made."<<endl;
			printf("125");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
			cerr<<"data "<<t<<" has been made."<<endl;
//			return 0;
		}
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("e");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("m_e");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='N'&&a[1]=='U'&&a[2]=='L')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("NUL");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='O'&&a[2]=='H')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("SOH");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='T'&&a[2]=='X')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("STX");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='E'&&a[1]=='T'&&a[2]=='X')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("ETX");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='E'&&a[1]=='O'&&a[2]=='T')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("EOT");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='E'&&a[1]=='N'&&a[2]=='Q')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("ENQ");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='A'&&a[1]=='C'&&a[2]=='K')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("ACK");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='B'&&a[1]=='E'&&a[2]=='L')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("BEL");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='B'&&a[1]=='S')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("BS");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='T'&&a[1]=='A'&&a[2]=='B')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("TAB");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='L'&&a[1]=='F')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("LF");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='V'&&a[1]=='T')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("VT");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='F'&&a[1]=='F')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("FF");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='C'&&a[1]=='R')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("CR");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='O')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("SO");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='I')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("SI");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='D'&&a[1]=='L'&&a[2]=='E')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("DLE");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='D'&&a[1]=='C'&&a[2]=='1')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("DC1");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='D'&&a[1]=='C'&&a[2]=='2')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("DC2");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='D'&&a[1]=='C'&&a[2]=='3')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("DC3");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='D'&&a[1]=='C'&&a[2]=='4')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("DC4");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='N'&&a[1]=='A'&&a[2]=='K')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("NAK");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='Y'&&a[2]=='N')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("SYN");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='E'&&a[1]=='T'&&a[2]=='B')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("ETB");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='C'&&a[1]=='A'&&a[2]=='N')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("CAN");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='E'&&a[1]=='M')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("EM");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='U'&&a[2]=='B')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("SUB");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='E'&&a[1]=='S'&&a[2]=='C')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("ESC");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='F'&&a[1]=='S')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("FS");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='G'&&a[1]=='S')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("GS");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='R'&&a[1]=='S')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("RS");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='U'&&a[1]=='S')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("US");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='S'&&a[1]=='p'&&a[2]=='a'&&a[3]=='c'&&a[4]=='e')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("Space");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[0]=='D'&&a[1]=='E'&&a[2]=='L')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("DEL");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
	}
	//	if(a[0]=='M'&&a[1]=='_')
	{
//		if(a[2]=='E')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_E");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='L'&&a[3]=='O'&&a[5]=='2')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_LOG2E");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='L'&&a[3]=='O'&&a[5]=='1')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_LOG10E");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='L'&&a[3]=='N'&&a[4]=='2')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_LN2");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='L'&&a[3]=='N'&&a[4]=='1')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_LN10");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='P'&&a[4]==' ')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_PI");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='P'&&a[4]=='2')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_PI_2");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='P'&&a[4]=='4')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_PI_4");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='1'&&a[4]=='P')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_1_PI");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='2'&&a[4]=='P')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_2_PI");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='2'&&a[4]=='S')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_2_SQRTPI");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='S'&&a[6]=='2')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_SQRT2");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
//		if(a[2]=='S'&&a[6]=='1')
		{
			sprintf(buf,"%s%d.in",problemname,++t);
			freopen(buf,"w",stdout);
			printf("M_SQRT1_2");
			fclose(stdout);
			sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
			system(buf);
			sprintf(buf,"\"%s.exe\"",problemname);
			system(buf);
			sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
			system(buf);
			sprintf(buf,"del %s.in",problemname);
			system(buf);
			sprintf(buf,"del %s.out",problemname);
			system(buf);
//			return 0;
		}
	}
	return 0;
}
