#include "testlib.h"
using namespace std;
int n;
string a[5],b[5];
int main(int argc,char *argv[])
{
	registerTestlibCmd(argc, argv);
	n=inf.readInt();
	for(int i=0;i<n;i++)
	{
		a[i]=ans.readString();
		b[i]=ouf.readString();
		if(a[i]!=b[i])
		{
			quitf(_wa, "Oh,no!Who teaches your math teacher?\n");
			return 0;
		}
	}
	quitf(_ok, "Yeah!Your coding anility is good.\n");
	return 0;
}
