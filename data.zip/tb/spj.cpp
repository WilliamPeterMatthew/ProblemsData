#include<string>
#include<fstream>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
ifstream input,ans,test;
ofstream fscore,freport;
int n;
string a[5],b[5];
int Judge()
{
	input>>n;
	for(int i=0;i<n;i++)
	{
		ans>>a[i];
		test>>b[i];
		if(a[i]!=b[i])
		{
			freport<<"Oh,no!Who teaches your math teacher?\n";
			return 0;
		}
	}
	freport<<"Yeah!Your coding anility is good.\n";
	return 1;
}

int main(int argc,char *argv[])
{
	input.open(argv[1]);
	test.open(argv[2]);
	ans.open(argv[3]);
	fscore.open(argv[5]);
	freport.open(argv[6]);

	int score=atoi(argv[4]);
	fscore<<score*Judge()<<endl;

	input.close();
	test.close();
	ans.close();
	fscore.close();
	freport.close();
	return 0;
}
