#include<bits/stdc++.h>
using namespace std;
const int T=10,L=200;
const char* problemname="tb";
char buf[L]={};
int randomint(int l,int r)
{
	return (rand()*32768+rand())%(r-l+1)+l;
}
void make_data(int t)
{	
	bool tag=t>=6,tg=t>6;
	printf("%d",tag?t-5:t);
	for(int i=1;i<=(tag?t-5:t);i++)printf(" %c",'a'-1+i);printf("\n");
	switch(t)
	{
		case 1:{
			printf("a==5\n");
			break;
		}
		case 6:{
			printf("a==6\n");
			break;
		}
		case 2:{
			printf("a+b==1\na-b==-1\n");
			break;
		}
		case 3:{
			printf("a+b+c==6\nb+c==5\na+c==4\n");
			break;
		}
		case 4:{
			printf("a+c==4\nb+c==5\na+b+c==7\na+d==4");
			break;
		}
		case 5:{
			printf("a+b+c+d+e==-9\nb+c==-4\na+c==-3\na+d==-3\nd+e==-4");
			break;
		}
		case 7:{
			printf("a=&b\nb==2\n");
			break;
		}
		case 8:{
			printf("a&=b\nb==5\nc=*a\n");
			break;
		}
		case 9:{
			printf("a&=b\nb==5\nc=&d\nd==1\n");
			break;
		}
		case 10:{
			printf("a&=b\nb==5\nc=*a\nd=&e\ne==9\n");
			break;
		}
	}
	
	return ;
}
int main()
{
	srand(time(0));
	for(int t=1;t<=T;++t)
	{
		cerr<<"start time="<<clock()<<endl;
		sprintf(buf,"%s%d.in",problemname,t);
		freopen(buf,"w",stdout);
		
		make_data(t);
		
		fclose(stdout);
		cerr<<"t1="<<clock()<<endl;
		sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
		system(buf);
		sprintf(buf,"\"%s.exe\"",problemname);
		system(buf);
		sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
		system(buf);
		sprintf(buf,"del %s.in",problemname);
		system(buf);
		sprintf(buf,"del %s.out",problemname);
		system(buf);
		cerr<<"data "<<t<<" has been made."<<endl;
		cerr<<"end time="<<clock()<<endl;
	}
}
