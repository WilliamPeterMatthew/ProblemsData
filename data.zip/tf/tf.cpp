#include<bits/stdc++.h>
using namespace std;
int n,a[20]={0,0,0,1,1,2,3,7,21,49,165,552,2176,9988,46972,253293,1388705};
int main()
{
	freopen("tf.in","r",stdin);
	freopen("tf.out","w",stdout);
	scanf("%d",&n);
	printf("%d",a[n]);
	return 0;
}
