#include<bits/stdc++.h>
using namespace std;
const int T=50,L=200;
const char* problemname="te";
char buf[L]={};
char hsm[50][50]={"sin","sine","cos","cosine","tan","tangent","cot","cotangent","sec","secant","csc","cosecant","asin","arcsine","acos","arccosine","atan","arctangent","acot","arccotangent","asec","arcsecant","acsc","arccosecant","sinh","hyperbolicsine","cosh","hyperboliccosine","tanh","hyperbolictangent","coth","hyperboliccotangent","sech","hyperbolicsecant","csch","hyperboliccosecant","asinh","archyperbolicsine","acosh","archyperboliccosine","atanh","archyperbolictangent","acoth","archyperboliccotangent","asech","archyperbolicsecant","acsch","archyperboliccosecant"};
int randomint(int l,int r)
{
	return (rand()*32768+rand())%(r-l+1)+l;
}
void make_data(int t)
{	
	if(t==1)printf("sin ");
	else if(t==2)printf("cos ");
	else if(t==41||t==42||t==47||t==48)printf("%s ",hsm[t-34]);
	else printf("%s ",hsm[t-3]);
	if((t>=21&&t<=26)||(t>=45&&t<=50))
	{
		if(randomint(0,1))printf("-");
		printf("%d.",randomint(3,9));
	}
	else
	{
		if(randomint(0,1))printf("-");
		printf("0.");
	}
	printf("%06d",randomint(1,999999));
	return ;
}
int main()
{
	srand(time(0));
	for(int t=1;t<=T;++t)
	{
		cerr<<"start time="<<clock()<<endl;
		sprintf(buf,"%s%d.in",problemname,t);
		freopen(buf,"w",stdout);
		
		make_data(t);
		
		fclose(stdout);
		cerr<<"t1="<<clock()<<endl;
		sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
		system(buf);
		sprintf(buf,"\"%s.exe\"",problemname);
		system(buf);
		sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
		system(buf);
		sprintf(buf,"del %s.in",problemname);
		system(buf);
		sprintf(buf,"del %s.out",problemname);
		system(buf);
		cerr<<"data "<<t<<" has been made."<<endl;
		cerr<<"end time="<<clock()<<endl;
	}
}
