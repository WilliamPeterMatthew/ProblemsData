#include<string>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
typedef long long ll;
ifstream input,ans,test;
ofstream fscore,freport;
double a,b;
int Judge()
{
	ans>>a;
	test>>b;
	if(fabs(a-b)<0.000001)
	{
		freport<<"Yeah!You are very clever.\n";
		return 1;
	}
	else
	{
		freport<<"Oh,no!You give a wrong answer.\n";
		return 0;
	}
	return 1;
}

int main(int argc,char *argv[])
{
	input.open(argv[1]);
	test.open(argv[2]);
	ans.open(argv[3]);
	fscore.open(argv[5]);
	freport.open(argv[6]);

	int score=atoi(argv[4]);
	fscore<<score*Judge()<<endl;

	input.close();
	test.close();
	ans.close();
	fscore.close();
	freport.close();
	return 0;
}
