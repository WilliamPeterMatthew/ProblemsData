#include "testlib.h"
using namespace std;
int a,b;
int main(int argc,char *argv[])
{
	registerTestlibCmd(argc, argv);
	a=ans.readInt();
	b=ouf.readInt();
	if(a==b)
	{
		quitf(_ok, "Yeah!You are perfect!\n");
	}
	else
	{
		quitf(_wa, "Oh,no!It's not a knot.\n");
	}
	return 0;
}
