#include<string>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
typedef long long ll;
ifstream input,ans,test;
ofstream fscore,freport;
int a,b;
int Judge()
{
	ans>>a;
	test>>b;
	if(a==b)
	{
		freport<<"Yeah!You are perfect!\n";
		return 1;
	}
	else
	{
		freport<<"Oh,no!It's not a knot.\n";
		return 0;
	}
	return 1;
}

int main(int argc,char *argv[])
{
	input.open(argv[1]);
	test.open(argv[2]);
	ans.open(argv[3]);
	fscore.open(argv[5]);
	freport.open(argv[6]);

	int score=atoi(argv[4]);
	fscore<<score*Judge()<<endl;

	input.close();
	test.close();
	ans.close();
	fscore.close();
	freport.close();
	return 0;
}
