#include "testlib.h"
using namespace std;
string a,b;
int main(int argc,char *argv[])
{
	registerTestlibCmd(argc, argv);
	a=ans.readString();
	b=ouf.readString();
	if(a==b)
	{
		quitf(_ok, "Yeah!Let's play Minecraft.\n");
	}
	else
	{
		quitf(_wa, "Oh,no!It seems like you don't know the game.\n");
	}
	return 0;
}
