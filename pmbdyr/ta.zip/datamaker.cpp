#include<bits/stdc++.h>
using namespace std;
const int T=50,L=200;
const char* problemname="ta";
char buf[L]={};
int randomint(int l,int r)
{
	return (rand()*32768+rand())%(r-l+1)+l;
}
void make_data(int t)
{	
	printf("%d\n",t-1);
	return ;
}
int main()
{
	srand(time(0));
	for(int t=1;t<=T;++t)
	{
		cerr<<"start time="<<clock()<<endl;
		sprintf(buf,"%s%d.in",problemname,t);
		freopen(buf,"w",stdout);
		
		make_data(t);
		
		fclose(stdout);
		cerr<<"t1="<<clock()<<endl;
		sprintf(buf,"copy %s%d.in %s.in >nul",problemname,t,problemname);
		system(buf);
		sprintf(buf,"\"%s.exe\"",problemname);
		system(buf);
		sprintf(buf,"copy %s.out %s%d.ans >nul",problemname,problemname,t);
		system(buf);
		sprintf(buf,"del %s.in",problemname);
		system(buf);
		sprintf(buf,"del %s.out",problemname);
		system(buf);
		cerr<<"data "<<t<<" has been made."<<endl;
		cerr<<"end time="<<clock()<<endl;
	}
}
