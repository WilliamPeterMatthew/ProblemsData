#include<bits/stdc++.h>
using namespace std;
#define cot(x) 1/tan(x)
#define sec(x) 1/cos(x)
#define csc(x) 1/tan(x)
#define acot(x) M_PI_2-atan(x)
#define asec(x) acos(1/x)
#define acsc(x) asin(1/x)
#define coth(x) 1/tanh(x)
#define sech(x) 1/cosh(x)
#define csch(x) 1/tanh(x)
#define asinh(x) log(x+sqrt(x*x+1))
#define acosh(x) log(x+sqrt(x*x-1))
#define atanh(x) log((1+x)/(1-x))/2
#define acoth(x) atanh(1/x)
#define asech(x) acosh(1/x)
#define acsch(x) asinh(1/x)
char c[50],hsm[50][50]={"sin","sine","cos","cosine","tan","tangent","cot","cotangent","sec","secant","csc","cosecant","asin","arcsine","acos","arccosine","atan","arctangent","acot","arccotangent","asec","arcsecant","acsc","arccosecant","sinh","hyperbolicsine","cosh","hyperboliccosine","tanh","hyperbolictangent","coth","hyperboliccotangent","sech","hyperbolicsecant","csch","hyperboliccosecant","asinh","archyperbolicsine","acosh","archyperboliccosine","atanh","archyperbolictangent","acoth","archyperboliccotangent","asech","archyperbolicsecant","acsch","archyperboliccosecant"};
double a,ans;
int main()
{
	freopen("te.in","r",stdin);
	freopen("te.out","w",stdout);
	cin>>c>>a;
	for(int i=0,tag;i<48;i++)
	{
		tag=0;
		for(int j=0;j<strlen(hsm[i]);j++)
		{
			if(c[j]!=hsm[i][j])tag=1,j=strlen(hsm[i]);
		}
		if(!tag)
		{
			switch(i/2+1)
			{
				case 1: {ans=sin(a);break;}
				case 2: {ans=cos(a);break;}
				case 3: {ans=tan(a);break;}
				case 4: {ans=cot(a);break;}
				case 5: {ans=sec(a);break;}
				case 6: {ans=csc(a);break;}
				case 7: {ans=asin(a);break;}
				case 8: {ans=acos(a);break;}
				case 9: {ans=atan(a);break;}
				case 10:{ans=acot(a);break;}
				case 11:{ans=asec(a);break;}
				case 12:{ans=acsc(a);break;}
				case 13:{ans=sinh(a);break;}
				case 14:{ans=cosh(a);break;}
				case 15:{ans=tanh(a);break;}
				case 16:{ans=coth(a);break;}
				case 17:{ans=sech(a);break;}
				case 18:{ans=csch(a);break;}
				case 19:{ans=asinh(a);break;}
				case 20:{ans=acosh(a);break;}
				case 21:{ans=atanh(a);break;}
				case 22:{ans=acoth(a);break;}
				case 23:{ans=asech(a);break;}
				case 24:{ans=acsch(a);break;}
			}
		}
	}
	printf("%.6lf",ans);
	return 0;
}
