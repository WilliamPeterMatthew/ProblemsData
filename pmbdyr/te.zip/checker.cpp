#include "testlib.h"
using namespace std;
double a,b;
int main(int argc,char *argv[])
{
	registerTestlibCmd(argc, argv);
	a=ans.readDouble();
	b=ouf.readDouble();
	if(fabs(a-b)<0.000001)
	{
		quitf(_ok, "Yeah!You are very clever.\n");
	}
	else
	{
		quitf(_wa, "Oh,no!You give a wrong answer.\n");
	}
	return 0;
}
