#include<bits/stdc++.h>
using namespace std;
string b[5];
int n,tag,m;
int a[10][10];
char c[5];
int main()
{
	freopen("tb.in","r",stdin);
	freopen("tb.out","w",stdout);
	scanf("%d",&n);
	if(n==1)
	{
		scanf(" %c",&c[0]);
		cin>>b[0];
		cout<<b[0];
	}
	for(int i=0;i<n;i++)
	{
		scanf(" %c",&c[i]);
	}
	for(int i=0;i<n;i++)
	{
		scanf("\n");cin>>b[i];
		for(int j=0;j<b[i].length();j++)
		{
			if(b[i][j]=='*'||b[i][j]=='&')tag=1;
		}
	}
	if(!tag)
	{
		for(int i=0,tg;i<n;i++)
		{
			tg=0;
			for(int j=0;j<b[i].length();j++)
			{
				if(b[i][j]<='9'&&b[i][j]>='0')
				{
					while(b[i][j+1]!=c[tg])tg++;
					if(j>=1&&b[i][j-1]=='-')a[i][tg]='0'-b[i][j];
					else b[i][j]-'0';
					j++;
				}
				else if(b[i][j]<='z'&&b[i][j]>='a')
				{
					while(b[i][j]!=c[tg])tg++;
					if(j>=1&&b[i][j-1]=='-')a[i][tg]=-1;
					else a[i][tg]=1;
					j++;
				}
			}
		}
		for(int j = 0; j < n; j++)
		{  
	        int max = 0;  
	        int imax = 0;  
	        for(int i = j; i < n; i++)
			{  
	            if(imax < fabs(a[i][j]))
				{  
	                imax = fabs(a[i][j]);  
	                max = a[i][j];
	                m = i;  
	            }  
	        }  
	  
	        if(fabs(a[j][j]) != max)
			{            
	            int b = 0;  
	            for(int k = j;k < n + 1; k++)
				{  
	                b = a[j][k];  
	                a[j][k] = a[m][k];  
	                a[m][k] = b;  
	            }  
	        }  
	  
	        for(int r = j;r < n + 1;r++)
			{  
	            a[j][r] = a[j][r] / max;
	        }  
	  
	        for(int i = j + 1;i < n; i++)
			{  
	            double c = a[i][j];  
	            if(c == 0)  continue;  
	            for(int s = j;s < n + 1;s++)
				{  
	                double tempdata = a[i][s];  
	                a[i][s] = a[i][s] - a[j][s] * c;
	            }  
	        }  
	    }  
	  
	    for(int i = n - 2; i >= 0; i--)
		{  
	        for(int j = i + 1;j < n; j++)
			{  
	            int tempData = a[i][j];  
	            int data1 = a[i][n];  
	            int data2 = a[j][n];  
	            a[i][n] = a[i][n] - a[j][n] * a[i][j];  
	        }  
	    }
		for(int i=0;i<n;i++)
		{
			printf("%c==%d\n",c[i],a[i][n]);
		}  
	}
	else
	{
		int x[5]={0,0,0,0,0};
		int *y[5]={0,0,0,0,0};
		for(int i=0,tga,tgb;i<n;i++)
		{
			tga=tgb=0;
			if(b[i][3]=='*')
			{
				while(b[i][0]!=c[tga])tga++;
				while(b[i][4]!=c[tgb])tgb++;
				x[tga]=*y[tgb];
			}
			else if(b[i][3]=='&')
			{
				while(b[i][0]!=c[tga])tga++;
				while(b[i][4]!=c[tgb])tgb++;
				y[tga]=&x[tgb];
			}
			else
			{
				while(b[i][0]!=c[tga])tga++;
				if(b[i][3]=='0')x[tga]='0'-b[i][4];
				x[tga]=b[i][3]-'0';
			}
		}
		for(int i=0;i<n;i++)
		{
			printf("%c==",c[i]);
			if(x[i]==0)cout<<y[i]<<endl;
			else cout<<x[i]<<endl;
		}
	}
	return 0;
}

